///////////////////////////////////////// EJERCICIO 1 /////////////////////////////////////////////////////////////////

fetch("https://pokeapi.co/api/v2/pokemon/19/")
    .then((response) => response.json())
    .then((data) => {

        console.log('Habilidad oculta: ', data.abilities[1].is_hidden);

        console.log('Nombre: '+ data.name);

        console.log('Versión del juego: ' + data.game_indices[5].version.name);

        console.log('Movimiento: '+ data.moves[2].move.name);
        })

    .catch((error) => {
    console.log('Error obteniendo datos, intente de nuevo más tarde. ', error);
    });

////////////////////////////// EJERCICIO 2 //////////////////////////////////////////////////

const nuevoUsuario = {
    first_name: "Ferdinando",
    last_name: "Casadio",
    email: "ferdisation@jotmeil.com"
};

fetch("https://reqres.in/api/users", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(nuevoUsuario)
})

    .then(response => response.json())
    .then(data => {

        const profileInfo = `
        Perfil creado:
        -----------------
        Nombre: ${data.first_name} ${data.last_name}
        Email: ${data.email}
        ID: ${data.id}
        Fecha de Creación: ${data.createdAt}`;

        console.log(profileInfo)

    ;})

    .catch(error => {
    console.log("Error al crear el perfil:", error);
    });

////////////////////////////////////////////////// EJERCICIO 3 //////////////////////////////

fetch("https://reqres.in/api/users?page=1")

    .then(response => response.json())
    .then(data => {

        const george = data.data[0];
        document.getElementById("perfilGeorge").innerHTML = `
        <img src="${george.avatar}" alt="Avatar de ${george.first_name}" width="200" height="200">

        <h2>${george.first_name} ${george.last_name}</h2>
        <p><strong>Email:</strong> ${george.email}</p>`;

        const userInfo = `
        Perfil de George leído:
        -----------------
        ID: ${george.id}
        Nombre: ${george.first_name} ${george.last_name}
        Email: ${george.email}
        Avatar: ${george.avatar}
        `;

        console.log(userInfo);

    })

    .catch(error => {
    console.log("Error al crear el perfil:", error);
    });

//////////////////////////////////////////   EJERCICIO 4    //////////////////////////////////////////////////////

const apiKey = "4d23f55c74e5f634f7ae9b8c04a1e5ac";
const city = "Barcelona";
const lang = "es";
const units = "metric";
const climaWeb = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&lang=${lang}&units=${units}`;

fetch(climaWeb)
    .then(response => response.json())
    .then(data => {

        const meteo = data.weather[0].description;
        const temperatura = data.main.temp;
        const humedad = data.main.humidity;

        const InfoClima = document.getElementById("climaDiv");

        InfoClima.innerHTML = `
            <p><strong>Clima:</strong> ${meteo}</p>
            <p><strong>Temperatura:</strong> ${temperatura} °C</p>
            <p><strong>Humedad:</strong> ${humedad} %</p>
        `;
    })

    .catch(error => {
    console.error("Error al obtener el clima:", error);
    });